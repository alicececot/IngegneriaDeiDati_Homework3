package org.example;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.core.LowerCaseFilterFactory;
import org.apache.lucene.analysis.core.WhitespaceTokenizerFactory;
import org.apache.lucene.analysis.custom.CustomAnalyzer;
import org.apache.lucene.analysis.miscellaneous.PerFieldAnalyzerWrapper;
import org.apache.lucene.analysis.miscellaneous.WordDelimiterGraphFilterFactory;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.*;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.search.*;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.*;

public class Evaluator {

    public static double meanReciprocalRank(List<Integer> relevances) {
        for (int i = 0; i < relevances.size(); i++) {
            int relevance = relevances.get(i);
            if (relevance > 0) {
                return 1.0 / (i + 1);
            }
        }
        return 0.0;
    }

    public static double ndcg(List<Integer> relevances, int k) {
        double dcg = 0.0;
        for (int i = 0; i < Math.min(k, relevances.size()); i++) {
            int relevance = relevances.get(i);
            dcg += (Math.pow(2, relevance) - 1) / (Math.log(i + 2) / Math.log(2));
        }

        double idcg = 0.0;
        List<Integer> sortedRelevances = new ArrayList<>(relevances);
        sortedRelevances.sort((a, b) -> b - a);
        for (int i = 0; i < Math.min(k, sortedRelevances.size()); i++) {
            int relevance = sortedRelevances.get(i);
            idcg += (Math.pow(2, relevance) - 1) / (Math.log(i + 2) / Math.log(2));
        }

        return idcg == 0.0 ? 0.0 : dcg / idcg;
    }
}





