package org.example;

import org.apache.lucene.queryparser.classic.ParseException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AppEvaluation {

        public static void main(String[] args) {
            try {
                Searcher searcher = new Searcher();

                List<String> queries = new ArrayList<>();
                queries.add("Accuracy on CIFAR-10 for ResNet");
                queries.add("Accuracy on dataset MNIST for CNN");
                queries.add("Precision object detection model on PASCAL VOC");
                queries.add("Recall of R-CNN on COCO dataset");
                queries.add("Accuracy of VQA dataset on ViLT");

                List<Double> mrrList = new ArrayList<>();
                List<Double> ndcgList = new ArrayList<>();

                for (String query : queries) {
                    List<Map<String, String>> results = searcher.search(query);

                    List<Integer> relevances = new ArrayList<>();
                    System.out.println("You are analyzing:" + query);
                    for (int i = 0; i < Math.min(10, results.size()); i++) {
                        System.out.println("Evaluate the document:");
                        System.out.println("Filename: " + results.get(i).get("filename"));
                        System.out.println("Table ID: " + results.get(i).get("tableKey"));
                        System.out.print("Insert relevance (0 - Irrelevant, 1 - Minimally relevant, 2 - Moderately relevant, 3 - Highly relevant): ");
                        relevances.add(new java.util.Scanner(System.in).nextInt());
                    }

                    double mrr = Evaluator.meanReciprocalRank(relevances);
                    double ndcg = Evaluator.ndcg(relevances, relevances.size());

                    mrrList.add(mrr);
                    ndcgList.add(ndcg);

                    System.out.println("MRR for: '" + query + "': " + mrr);
                    System.out.println("NDCG for: '" + query + "': " + ndcg);
                }

                double totalMRR = mrrList.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
                double totalNDCG = ndcgList.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);

                System.out.println("Mean Reciprocal Rank (MRR) : " + totalMRR);
                System.out.println("Mean Normalized Discounted Cumulative Gain (NDCG): " + totalNDCG);

            } catch (IOException | ParseException e) {
                e.printStackTrace();
            }
        }

}
