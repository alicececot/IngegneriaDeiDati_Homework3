package org.example;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.miscellaneous.PerFieldAnalyzerWrapper;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.codecs.simpletext.SimpleTextCodec;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.lucene.analysis.custom.CustomAnalyzer;
import org.apache.lucene.analysis.core.WhitespaceTokenizerFactory;
import org.apache.lucene.analysis.miscellaneous.WordDelimiterGraphFilterFactory;
import org.apache.lucene.analysis.core.LowerCaseFilterFactory;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Indexer {

    private static final String HTML_FILES_DIR = "/Users/alicececot/Desktop/ingegneria dei dati/urls_htmls_tables/all_tables";
    private static final String INDEX_DIR = "index";

    public static void main(String[] args) {
        int documentCount = 0;

        long startTime = System.currentTimeMillis();

        try {
            Directory directory = FSDirectory.open(Paths.get(INDEX_DIR));

            Map<String, Analyzer> perFieldAnalyzers = new HashMap<>();
            perFieldAnalyzers.put("caption", myAnalyzer());
            perFieldAnalyzers.put("table", myAnalyzer());
            perFieldAnalyzers.put("footnotes", myAnalyzer());
            perFieldAnalyzers.put("references", myAnalyzer());

            Analyzer perFieldAnalyzer = new PerFieldAnalyzerWrapper(new StandardAnalyzer(), perFieldAnalyzers);

            IndexWriterConfig config = new IndexWriterConfig(perFieldAnalyzer);
            config.setCodec(new SimpleTextCodec());
            config.setOpenMode(IndexWriterConfig.OpenMode.CREATE);
            IndexWriter writer = new IndexWriter(directory, config);

            File folder = new File(HTML_FILES_DIR);
            File[] jsonFiles = folder.listFiles((dir, name) -> name.endsWith(".json") && !name.startsWith("._"));

            if (jsonFiles != null) {
                for (File jsonFile : jsonFiles) {
                    try {
                        ObjectMapper mapper = new ObjectMapper();
                        JsonNode rootNode = mapper.readTree(jsonFile);

                        for (Iterator<String> it = rootNode.fieldNames(); it.hasNext(); ) {
                            String tableKey = it.next();
                            JsonNode tableNode = rootNode.get(tableKey);

                            String caption = tableNode.has("caption") ? tableNode.get("caption").asText() : "";
                            String table = tableNode.has("table") ? tableNode.get("table").asText() : "";
                            String footnotes = tableNode.has("footnotes") ? tableNode.get("footnotes").asText() : "";
                            String references = tableNode.has("references") ? tableNode.get("references").toString() : "";

                            Document doc = new Document();
                            doc.add(new TextField("filename", jsonFile.getName(), TextField.Store.YES));
                            doc.add(new TextField("tableKey", tableKey, TextField.Store.YES));
                            doc.add(new TextField("caption", caption, TextField.Store.YES));
                            doc.add(new TextField("table", table, TextField.Store.YES));
                            doc.add(new TextField("footnotes", footnotes, TextField.Store.YES));
                            doc.add(new TextField("references", references, TextField.Store.YES));

                            writer.addDocument(doc);
                            documentCount++;
                        }
                    } catch (Exception e) {
                        System.err.println("Errore nella lettura del file: " + jsonFile.getName() + " - " + e.getMessage());
                    }
                }
            }

            writer.commit();
            writer.close();

            long endTime = System.currentTimeMillis();

            long duration = endTime - startTime;
            double durationInSeconds = duration / 1000.0;

            System.out.println("Number of indexed table: " + documentCount);
            System.out.println("Total indexing time: " + durationInSeconds + " second");
            double averageIndexingTimePerDocument = documentCount > 0 ? (durationInSeconds / documentCount) : 0;
            System.out.println("Average total indexing per table: " + averageIndexingTimePerDocument + " second");


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private static Analyzer myAnalyzer() throws IOException {
        return CustomAnalyzer.builder()
                .withTokenizer(WhitespaceTokenizerFactory.class)
                .addTokenFilter(LowerCaseFilterFactory.class)
                .addTokenFilter(WordDelimiterGraphFilterFactory.class)
                .build();
    }

}
